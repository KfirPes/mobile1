# 24B-11345A-L02-03

## L02

- TextViews
- ImageViews
- RelativeLayout
- LinearLayout
- Material3
- Resource Files - Strings, dimens, colors
- Buttons

## L03

- Buttons
- Data Models – builder Design Pattern
- JavaBeans
- Business Logic - Encapsulation, Code Layering
- Multiple activities
- Intents
- Passing data between Activities