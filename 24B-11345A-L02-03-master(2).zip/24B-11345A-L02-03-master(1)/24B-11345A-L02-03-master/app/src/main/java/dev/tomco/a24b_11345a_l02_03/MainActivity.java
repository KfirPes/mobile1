package dev.tomco.a24b_11345a_l02_03;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;

import java.util.Random;

import dev.tomco.a24b_11345a_l02_03.Logic.GameManager;

public class MainActivity extends AppCompatActivity {

    private MaterialTextView main_LBL_score;
    private MaterialButton main_BTN_yes;
    private MaterialButton main_BTN_no;
    private AppCompatImageView[] main_IMG_hearts;

    private LinearLayoutCompat[][] main_obstacle;
    private LinearLayoutCompat[] main_body;

    private GameManager gameManager;
    private static final long DELAY = 1000L;
    final Handler handler = new Handler();
    private boolean timerOn = false;
    private long startTime;
    private int crashes=0;
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(this, DELAY);
            main_obstacle[gameManager.getRowObs()][gameManager.getColObs()]
                    .setVisibility(View.INVISIBLE);
            if (gameManager.getRowObs()!=14) {
                main_obstacle[gameManager.getRowObs() + 1][gameManager.getColObs()]
                        .setVisibility(View.VISIBLE);
                gameManager.setRowObs();
            }
            else{
                Random rnd=new Random();
                int randomNumber = rnd.nextInt(3);
                main_obstacle[0][randomNumber]
                        .setVisibility(View.VISIBLE);
                gameManager.setCol(randomNumber);
                refreshUI();
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });

        findViews();
        gameManager = new GameManager(main_IMG_hearts.length);
        initViews();
    }

    private void initViews() {
        main_LBL_score.setText(String.valueOf(gameManager.getScore()));
        main_BTN_yes.setOnClickListener(view -> LeftRightBody(true));
        main_BTN_no.setOnClickListener(view -> LeftRightBody(false));
        refreshUI();
        refreshObstracle();
    }
    private void LeftRightBody(boolean where){
        gameManager.setNumBody(where);
        int num=gameManager.getNumBody();
        for (int i=0;i<3;i++)
        {
            if (num==i){
                main_body[i].setVisibility(View.VISIBLE);
            }
            else
                main_body[i].setVisibility(View.INVISIBLE);
        }

    }

    private void refreshUI() {
        //lost:
        if (gameManager.isGameLost()) {
            //show "LOST!"
            Log.d("Game Status:", "GAME OVER " + gameManager.getScore());
            toastAndVibrate("😭 GAME OVER"+ gameManager.getScore());
            gameManager.setWrongAnswers(0);
            for(int i=0;i<3;i++)
                main_IMG_hearts[i].setVisibility(View.VISIBLE);
        }
        //won:


        //game still on:
        else {
            main_LBL_score.setText(String.valueOf(gameManager.getScore()));
            if (gameManager.getWrongAnswers() != 0) {
                main_IMG_hearts[main_IMG_hearts.length - gameManager.getWrongAnswers()]
                        .setVisibility(View.INVISIBLE);
            }
            if(gameManager.getWrongAnswers()>crashes) {
                crashes = gameManager.getWrongAnswers();
                toastAndVibrate("crash");
            }
        }
    }
    private void refreshObstracle(){
        Random rnd=new Random();
        int randomNumber = rnd.nextInt(3);
        main_obstacle[0][randomNumber]
                .setVisibility(View.VISIBLE);
        gameManager.setCol(randomNumber);
        if (!timerOn) {
            startTime = System.currentTimeMillis();
            handler.postDelayed(runnable, 0);
            timerOn = true;
        }
    }

    private void findViews() {
        main_LBL_score = findViewById(R.id.main_LBL_score);
        main_BTN_yes = findViewById(R.id.main_BTN_yes);
        main_BTN_no = findViewById(R.id.main_BTN_no);
        main_IMG_hearts = new AppCompatImageView[]{
                findViewById(R.id.main_IMG_heart1),
                findViewById(R.id.main_IMG_heart2),
                findViewById(R.id.main_IMG_heart3)
        };
        main_obstacle = new LinearLayoutCompat[15][3];
        main_obstacle[0][0]=findViewById(R.id.main_Obstacle1);main_obstacle[0][1]=findViewById(R.id.main_Obstacle2);main_obstacle[0][2]=findViewById(R.id.main_Obstacle3);
        main_obstacle[1][0]=findViewById(R.id.main_Obstacle4);main_obstacle[1][1]=findViewById(R.id.main_Obstacle5);main_obstacle[1][2]=findViewById(R.id.main_Obstacle6);
        main_obstacle[2][0]=findViewById(R.id.main_Obstacle7);main_obstacle[2][1]=findViewById(R.id.main_Obstacle8);main_obstacle[2][2]=findViewById(R.id.main_Obstacle9);
        main_obstacle[3][0]=findViewById(R.id.main_Obstacle10);main_obstacle[3][1]=findViewById(R.id.main_Obstacle11);main_obstacle[3][2]=findViewById(R.id.main_Obstacle12);
        main_obstacle[4][0]=findViewById(R.id.main_Obstacle13);main_obstacle[4][1]=findViewById(R.id.main_Obstacle14);main_obstacle[4][2]=findViewById(R.id.main_Obstacle15);
        main_obstacle[5][0]=findViewById(R.id.main_Obstacle16);main_obstacle[5][1]=findViewById(R.id.main_Obstacle17);main_obstacle[5][2]=findViewById(R.id.main_Obstacle18);
        main_obstacle[6][0]=findViewById(R.id.main_Obstacle19);main_obstacle[6][1]=findViewById(R.id.main_Obstacle20);main_obstacle[6][2]=findViewById(R.id.main_Obstacle21);
        main_obstacle[7][0]=findViewById(R.id.main_Obstacle22);main_obstacle[7][1]=findViewById(R.id.main_Obstacle23);main_obstacle[7][2]=findViewById(R.id.main_Obstacle24);
        main_obstacle[8][0]=findViewById(R.id.main_Obstacle25);main_obstacle[8][1]=findViewById(R.id.main_Obstacle26);main_obstacle[8][2]=findViewById(R.id.main_Obstacle27);
        main_obstacle[9][0]=findViewById(R.id.main_Obstacle28);main_obstacle[9][1]=findViewById(R.id.main_Obstacle29);main_obstacle[9][2]=findViewById(R.id.main_Obstacle30);
        main_obstacle[10][0]=findViewById(R.id.main_Obstacle31);main_obstacle[10][1]=findViewById(R.id.main_Obstacle32);main_obstacle[10][2]=findViewById(R.id.main_Obstacle33);
        main_obstacle[11][0]=findViewById(R.id.main_Obstacle34);main_obstacle[11][1]=findViewById(R.id.main_Obstacle35);main_obstacle[11][2]=findViewById(R.id.main_Obstacle36);
        main_obstacle[12][0]=findViewById(R.id.main_Obstacle37);main_obstacle[12][1]=findViewById(R.id.main_Obstacle38);main_obstacle[12][2]=findViewById(R.id.main_Obstacle39);
        main_obstacle[13][0]=findViewById(R.id.main_Obstacle40);main_obstacle[13][1]=findViewById(R.id.main_Obstacle41);main_obstacle[13][2]=findViewById(R.id.main_Obstacle42);
        main_obstacle[14][0]=findViewById(R.id.main_Obstacle43);main_obstacle[14][1]=findViewById(R.id.main_Obstacle44);main_obstacle[14][2]=findViewById(R.id.main_Obstacle45);
        main_body=new LinearLayoutCompat[]{findViewById(R.id.main_body1),findViewById(R.id.main_body2),findViewById(R.id.main_body3),};
    }
    public void toastAndVibrate(String text) {
        vibrate();
        toast(text);
    }

    public void toast(String text) {
        Toast.makeText(this, text,
                Toast.LENGTH_LONG).show();
    }

    public void vibrate() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // Vibrate for 500 milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(500);
        }
    }
}